package tpi.ui;

import java.util.List;
import java.util.Scanner;
import tpi.entities.Producto;
import tpi.exception.EntidadNoEncontradaException;
import tpi.exception.ValidacionException;
import tpi.service.CategoriaService;
import tpi.service.ProductoService;

public class MenuProducto {

    private final Scanner scanner;
    private final ProductoService productoService;
    private final CategoriaService categoriaService;

    public MenuProducto(Scanner scanner, ProductoService productoService,
            CategoriaService categoriaService) {
        this.scanner = scanner;
        this.productoService = productoService;
        this.categoriaService = categoriaService;
    }

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n--- PRODUCTOS ---");
            System.out.println("1. Listar");
            System.out.println("2. Listar por categoría");
            System.out.println("3. Crear");
            System.out.println("4. Editar");
            System.out.println("5. Eliminar");
            System.out.println("0. Volver");
            int opcion = ConsolaUtil.leerEntero(scanner, "Seleccione: ", 0, 5);

            switch (opcion) {
                case 1 -> listarGeneral();
                case 2 -> listarPorCategoria();
                case 3 -> crear();
                case 4 -> editar();
                case 5 -> eliminar();
                default -> volver = true;
            }
        }
    }

    private void listarGeneral() {
        List<Producto> productos = productoService.listarActivos();
        imprimirProductos(productos);
    }

    private void listarPorCategoria() {
        if (categoriaService.listarActivas().isEmpty()) {
            System.out.println("No hay categorías cargadas.");
            return;
        }
        System.out.println("\nCategorías disponibles:");
        categoriaService.listarActivas().forEach(System.out::println);
        try {
            long categoriaId = ConsolaUtil.leerLongPositivo(scanner, "Id de categoría: ");
            List<Producto> productos = productoService.listarActivosPorCategoria(categoriaId);
            imprimirProductos(productos);
        } catch (EntidadNoEncontradaException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void imprimirProductos(List<Producto> productos) {
        if (productos.isEmpty()) {
            System.out.println("No hay productos cargados.");
            return;
        }
        System.out.println("\nProductos:");
        productos.forEach(System.out::println);
    }

    private void crear() {
        if (categoriaService.listarActivas().isEmpty()) {
            System.out.println("Debe crear al menos una categoría antes de cargar productos.");
            return;
        }
        System.out.println("\nCategorías disponibles:");
        categoriaService.listarActivas().forEach(System.out::println);
        try {
            String nombre = ConsolaUtil.leerTexto(scanner, "Nombre: ", false);
            String descripcion = ConsolaUtil.leerTexto(scanner, "Descripción: ", true);
            double precio = ConsolaUtil.leerDoubleNoNegativo(scanner, "Precio: ");
            int stock = ConsolaUtil.leerIntNoNegativo(scanner, "Stock: ");
            String imagen = ConsolaUtil.leerTexto(scanner, "Imagen (ruta/nombre): ", true);
            boolean disponible = ConsolaUtil.leerBooleano(scanner, "¿Disponible?");
            long categoriaId = ConsolaUtil.leerLongPositivo(scanner, "Id de categoría: ");

            Producto producto = productoService.crear(nombre, descripcion, precio, stock, imagen,
                    disponible, categoriaId);
            System.out.println("Producto creado con id: " + producto.getId());
        } catch (ValidacionException | EntidadNoEncontradaException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void editar() {
        listarGeneral();
        try {
            long id = ConsolaUtil.leerLongPositivo(scanner, "Id de producto a editar: ");
            String nombre = ConsolaUtil.leerTexto(scanner, "Nuevo nombre (ENTER para mantener): ", true);
            String descripcion = ConsolaUtil.leerTexto(scanner, "Nueva descripción (ENTER para mantener): ", true);

            Double precio = null;
            String precioTxt = ConsolaUtil.leerTexto(scanner, "Nuevo precio (ENTER para mantener): ", true);
            if (!precioTxt.isEmpty()) {
                precio = Double.parseDouble(precioTxt.replace(',', '.'));
                if (precio < 0) {
                    throw new ValidacionException("El precio debe ser mayor o igual a 0.");
                }
            }

            Integer stock = null;
            String stockTxt = ConsolaUtil.leerTexto(scanner, "Nuevo stock (ENTER para mantener): ", true);
            if (!stockTxt.isEmpty()) {
                stock = Integer.parseInt(stockTxt);
                if (stock < 0) {
                    throw new ValidacionException("El stock debe ser mayor o igual a 0.");
                }
            }

            String imagen = ConsolaUtil.leerTexto(scanner, "Nueva imagen (ENTER para mantener): ", true);
            Boolean disponible = null;
            String dispTxt = ConsolaUtil.leerTexto(scanner, "¿Cambiar disponibilidad? S/N (ENTER omitir): ", true);
            if (dispTxt.equalsIgnoreCase("S")) {
                disponible = true;
            } else if (dispTxt.equalsIgnoreCase("N") && !dispTxt.isEmpty()) {
                disponible = false;
            }

            Long categoriaId = null;
            String catTxt = ConsolaUtil.leerTexto(scanner, "Nuevo id categoría (ENTER para mantener): ", true);
            if (!catTxt.isEmpty()) {
                categoriaId = Long.parseLong(catTxt);
            }

            productoService.editar(id,
                    nombre.isEmpty() ? null : nombre,
                    descripcion.isEmpty() ? null : descripcion,
                    precio, stock,
                    imagen.isEmpty() ? null : imagen,
                    disponible,
                    categoriaId);
            System.out.println("Producto actualizado correctamente.");
        } catch (NumberFormatException e) {
            System.out.println("Error: valor numérico inválido.");
        } catch (ValidacionException | EntidadNoEncontradaException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void eliminar() {
        listarGeneral();
        try {
            long id = ConsolaUtil.leerLongPositivo(scanner, "Id de producto a eliminar: ");
            if (!ConsolaUtil.leerConfirmacion(scanner, "¿Confirma eliminación?")) {
                System.out.println("Operación cancelada.");
                return;
            }
            productoService.eliminar(id);
            System.out.println("Producto eliminado lógicamente.");
        } catch (EntidadNoEncontradaException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
