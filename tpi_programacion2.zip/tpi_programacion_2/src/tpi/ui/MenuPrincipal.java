package tpi.ui;

import java.util.Scanner;
import tpi.AppContext;

public class MenuPrincipal {

    private final Scanner scanner;
    private final AppContext context;

    public MenuPrincipal(Scanner scanner, AppContext context) {
        this.scanner = scanner;
        this.context = context;
    }

    public void iniciar() {
        boolean salir = false;
        while (!salir) {
            System.out.println("\n=== SISTEMA DE PEDIDOS (FOOD STORE) ===");
            System.out.println("1. Categorías");
            System.out.println("2. Productos");
            System.out.println("3. Usuarios");
            System.out.println("4. Pedidos");
            System.out.println("0. Salir");
            int opcion = ConsolaUtil.leerEntero(scanner, "Seleccione: ", 0, 4);

            switch (opcion) {
                case 1 -> new MenuCategoria(scanner, context.getCategoriaService()).mostrar();
                case 2 -> new MenuProducto(scanner, context.getProductoService(),
                        context.getCategoriaService()).mostrar();
                case 3 -> new MenuUsuario(scanner, context.getUsuarioService()).mostrar();
                case 4 -> new MenuPedido(scanner, context.getPedidoService(),
                        context.getUsuarioService(), context.getProductoService()).mostrar();
                default -> salir = true;
            }
        }
        System.out.println("Gracias por usar Food Store.");
    }
}
