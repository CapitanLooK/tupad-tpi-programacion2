package tpi.ui;

import java.util.List;
import java.util.Scanner;
import tpi.entities.Categoria;
import tpi.exception.EntidadNoEncontradaException;
import tpi.exception.ValidacionException;
import tpi.service.CategoriaService;

public class MenuCategoria {

    private final Scanner scanner;
    private final CategoriaService categoriaService;

    public MenuCategoria(Scanner scanner, CategoriaService categoriaService) {
        this.scanner = scanner;
        this.categoriaService = categoriaService;
    }

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n--- CATEGORÍAS ---");
            System.out.println("1. Listar");
            System.out.println("2. Crear");
            System.out.println("3. Editar");
            System.out.println("4. Eliminar");
            System.out.println("0. Volver");
            int opcion = ConsolaUtil.leerEntero(scanner, "Seleccione: ", 0, 4);

            switch (opcion) {
                case 1 -> listar();
                case 2 -> crear();
                case 3 -> editar();
                case 4 -> eliminar();
                default -> volver = true;
            }
        }
    }

    private void listar() {
        List<Categoria> categorias = categoriaService.listarActivas();
        if (categorias.isEmpty()) {
            System.out.println("No hay categorías cargadas.");
            return;
        }
        System.out.println("\nCategorías activas:");
        for (Categoria categoria : categorias) {
            System.out.println(categoria);
        }
    }

    private void crear() {
        try {
            String nombre = ConsolaUtil.leerTexto(scanner, "Nombre: ", false);
            String descripcion = ConsolaUtil.leerTexto(scanner, "Descripción: ", false);
            Categoria categoria = categoriaService.crear(nombre, descripcion);
            System.out.println("Categoría creada con id: " + categoria.getId());
        } catch (ValidacionException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void editar() {
        listar();
        try {
            long id = ConsolaUtil.leerLongPositivo(scanner, "Id de categoría a editar: ");
            String nombre = ConsolaUtil.leerTexto(scanner, "Nuevo nombre (ENTER para mantener): ", true);
            String descripcion = ConsolaUtil.leerTexto(scanner, "Nueva descripción (ENTER para mantener): ", true);
            String nombreFinal = nombre.isEmpty() ? null : nombre;
            String descripcionFinal = descripcion.isEmpty() ? null : descripcion;
            categoriaService.editar(id, nombreFinal, descripcionFinal);
            System.out.println("Categoría actualizada correctamente.");
        } catch (EntidadNoEncontradaException | ValidacionException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void eliminar() {
        listar();
        try {
            long id = ConsolaUtil.leerLongPositivo(scanner, "Id de categoría a eliminar: ");
            if (!ConsolaUtil.leerConfirmacion(scanner, "¿Confirma eliminación?")) {
                System.out.println("Operación cancelada.");
                return;
            }
            categoriaService.eliminar(id);
            System.out.println("Categoría eliminada lógicamente.");
        } catch (EntidadNoEncontradaException | ValidacionException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
