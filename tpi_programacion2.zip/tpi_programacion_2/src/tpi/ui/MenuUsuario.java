package tpi.ui;

import java.util.List;
import java.util.Scanner;
import tpi.entities.Usuario;
import tpi.enums.Rol;
import tpi.exception.EntidadNoEncontradaException;
import tpi.exception.ValidacionException;
import tpi.service.UsuarioService;

public class MenuUsuario {

    private final Scanner scanner;
    private final UsuarioService usuarioService;

    public MenuUsuario(Scanner scanner, UsuarioService usuarioService) {
        this.scanner = scanner;
        this.usuarioService = usuarioService;
    }

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n--- USUARIOS ---");
            System.out.println("1. Listar");
            System.out.println("2. Crear");
            System.out.println("3. Editar");
            System.out.println("4. Eliminar");
            System.out.println("0. Volver");
            int opcion = ConsolaUtil.leerEntero(scanner, "Seleccione: ", 0, 4);

            switch (opcion) {
                case 1 -> listar();
                case 2 -> crear();
                case 3 -> editar();
                case 4 -> eliminar();
                default -> volver = true;
            }
        }
    }

    private void listar() {
        List<Usuario> usuarios = usuarioService.listarActivos();
        if (usuarios.isEmpty()) {
            System.out.println("No hay usuarios cargados.");
            return;
        }
        System.out.println("\nUsuarios activos:");
        usuarios.forEach(System.out::println);
    }

    private void crear() {
        try {
            String nombre = ConsolaUtil.leerTexto(scanner, "Nombre: ", false);
            String apellido = ConsolaUtil.leerTexto(scanner, "Apellido: ", false);
            String mail = ConsolaUtil.leerTexto(scanner, "Mail: ", false);
            String celular = ConsolaUtil.leerTexto(scanner, "Celular: ", false);
            String contrasenia = ConsolaUtil.leerTexto(scanner, "Contraseña: ", false);
            Rol rol = leerRol();
            Usuario usuario = usuarioService.crear(nombre, apellido, mail, celular, contrasenia, rol);
            System.out.println("Usuario creado con id: " + usuario.getId());
        } catch (ValidacionException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void editar() {
        listar();
        try {
            long id = ConsolaUtil.leerLongPositivo(scanner, "Id de usuario a editar: ");
            String nombre = ConsolaUtil.leerTexto(scanner, "Nuevo nombre (ENTER para mantener): ", true);
            String apellido = ConsolaUtil.leerTexto(scanner, "Nuevo apellido (ENTER para mantener): ", true);
            String mail = ConsolaUtil.leerTexto(scanner, "Nuevo mail (ENTER para mantener): ", true);
            String celular = ConsolaUtil.leerTexto(scanner, "Nuevo celular (ENTER para mantener): ", true);
            String contrasenia = ConsolaUtil.leerTexto(scanner, "Nueva contraseña (ENTER para mantener): ", true);
            Rol rol = leerRolOpcional();

            usuarioService.editar(id,
                    nombre.isEmpty() ? null : nombre,
                    apellido.isEmpty() ? null : apellido,
                    mail.isEmpty() ? null : mail,
                    celular.isEmpty() ? null : celular,
                    contrasenia.isEmpty() ? null : contrasenia,
                    rol);
            System.out.println("Usuario actualizado correctamente.");
        } catch (EntidadNoEncontradaException | ValidacionException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void eliminar() {
        listar();
        try {
            long id = ConsolaUtil.leerLongPositivo(scanner, "Id de usuario a eliminar: ");
            if (!ConsolaUtil.leerConfirmacion(scanner, "¿Confirma eliminación?")) {
                System.out.println("Operación cancelada.");
                return;
            }
            usuarioService.eliminar(id);
            System.out.println("Usuario eliminado lógicamente.");
        } catch (EntidadNoEncontradaException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private Rol leerRol() {
        System.out.println("Roles: 1-ADMIN  2-USUARIO");
        int opcion = ConsolaUtil.leerEntero(scanner, "Seleccione rol: ", 1, 2);
        return opcion == 1 ? Rol.ADMIN : Rol.USUARIO;
    }

    private Rol leerRolOpcional() {
        String cambiar = ConsolaUtil.leerTexto(scanner, "¿Cambiar rol? S/N: ", true);
        if (!cambiar.equalsIgnoreCase("S")) {
            return null;
        }
        return leerRol();
    }
}
