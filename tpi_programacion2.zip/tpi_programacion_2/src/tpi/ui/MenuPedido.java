package tpi.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import tpi.entities.Pedido;
import tpi.entities.Producto;
import tpi.entities.Usuario;
import tpi.enums.Estado;
import tpi.enums.FormaPago;
import tpi.exception.EntidadNoEncontradaException;
import tpi.exception.StockInvalidoException;
import tpi.exception.ValidacionException;
import tpi.service.PedidoService;
import tpi.service.PedidoService.DetalleSolicitud;
import tpi.service.ProductoService;
import tpi.service.UsuarioService;

public class MenuPedido {

    private final Scanner scanner;
    private final PedidoService pedidoService;
    private final UsuarioService usuarioService;
    private final ProductoService productoService;

    public MenuPedido(Scanner scanner, PedidoService pedidoService, UsuarioService usuarioService,
            ProductoService productoService) {
        this.scanner = scanner;
        this.pedidoService = pedidoService;
        this.usuarioService = usuarioService;
        this.productoService = productoService;
    }

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n--- PEDIDOS ---");
            System.out.println("1. Listar");
            System.out.println("2. Listar por usuario");
            System.out.println("3. Crear");
            System.out.println("4. Actualizar estado / forma de pago");
            System.out.println("5. Eliminar");
            System.out.println("0. Volver");
            int opcion = ConsolaUtil.leerEntero(scanner, "Seleccione: ", 0, 5);

            switch (opcion) {
                case 1 -> listarGeneral();
                case 2 -> listarPorUsuario();
                case 3 -> crear();
                case 4 -> actualizar();
                case 5 -> eliminar();
                default -> volver = true;
            }
        }
    }

    private void listarGeneral() {
        List<Pedido> pedidos = pedidoService.listarActivos();
        imprimirPedidos(pedidos);
    }

    private void listarPorUsuario() {
        List<Usuario> usuarios = usuarioService.listarActivos();
        if (usuarios.isEmpty()) {
            System.out.println("No hay usuarios cargados.");
            return;
        }
        System.out.println("\nUsuarios disponibles:");
        usuarios.forEach(System.out::println);
        try {
            long usuarioId = ConsolaUtil.leerLongPositivo(scanner, "Id de usuario: ");
            List<Pedido> pedidos = pedidoService.listarActivosPorUsuario(usuarioId);
            imprimirPedidos(pedidos);
        } catch (EntidadNoEncontradaException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void imprimirPedidos(List<Pedido> pedidos) {
        if (pedidos.isEmpty()) {
            System.out.println("No hay pedidos cargados.");
            return;
        }
        System.out.println("\nPedidos:");
        for (Pedido pedido : pedidos) {
            System.out.println(pedido);
            pedido.getDetalles().forEach(System.out::println);
        }
    }

    private void crear() {
        List<Usuario> usuarios = usuarioService.listarActivos();
        List<Producto> productos = productoService.listarActivos();
        if (usuarios.isEmpty()) {
            System.out.println("Debe crear al menos un usuario antes de registrar pedidos.");
            return;
        }
        if (productos.isEmpty()) {
            System.out.println("Debe crear al menos un producto antes de registrar pedidos.");
            return;
        }

        System.out.println("\nUsuarios disponibles:");
        usuarios.forEach(System.out::println);

        try {
            long usuarioId = ConsolaUtil.leerLongPositivo(scanner, "Id de usuario: ");
            Estado estado = leerEstado();
            FormaPago formaPago = leerFormaPago();

            List<DetalleSolicitud> detalles = new ArrayList<>();
            boolean agregarMas = true;
            while (agregarMas) {
                System.out.println("\nProductos disponibles:");
                productos.forEach(System.out::println);
                long productoId = ConsolaUtil.leerLongPositivo(scanner, "Id de producto: ");
                int cantidad = ConsolaUtil.leerIntNoNegativo(scanner, "Cantidad: ");
                if (cantidad <= 0) {
                    throw new ValidacionException("La cantidad debe ser mayor a 0.");
                }
                detalles.add(new DetalleSolicitud(productoId, cantidad));
                agregarMas = ConsolaUtil.leerConfirmacion(scanner, "¿Agregar otro detalle?");
            }

            if (!ConsolaUtil.leerConfirmacion(scanner, "¿Confirmar creación del pedido?")) {
                System.out.println("Creación cancelada.");
                return;
            }

            Pedido pedido = pedidoService.crearPedidoConDetalles(usuarioId, estado, formaPago, detalles);
            System.out.println("Pedido creado con id: " + pedido.getId() + " | Total: $" + pedido.getTotal());
        } catch (ValidacionException | EntidadNoEncontradaException | StockInvalidoException e) {
            System.out.println("Error: " + e.getMessage());
            System.out.println("El pedido no fue registrado.");
        }
    }

    private void actualizar() {
        listarGeneral();
        try {
            long id = ConsolaUtil.leerLongPositivo(scanner, "Id de pedido: ");
            System.out.println("Deje en blanco lo que no desea modificar.");
            Estado estado = leerEstadoOpcional();
            FormaPago formaPago = leerFormaPagoOpcional();
            if (estado == null && formaPago == null) {
                System.out.println("No se realizaron cambios.");
                return;
            }
            pedidoService.actualizarEstadoYPago(id, estado, formaPago);
            System.out.println("Pedido actualizado correctamente.");
        } catch (EntidadNoEncontradaException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void eliminar() {
        listarGeneral();
        try {
            long id = ConsolaUtil.leerLongPositivo(scanner, "Id de pedido a eliminar: ");
            if (!ConsolaUtil.leerConfirmacion(scanner, "¿Confirma eliminación?")) {
                System.out.println("Operación cancelada.");
                return;
            }
            pedidoService.eliminar(id);
            System.out.println("Pedido eliminado lógicamente.");
        } catch (EntidadNoEncontradaException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private Estado leerEstado() {
        System.out.println("Estados: 1-PENDIENTE 2-CONFIRMADO 3-TERMINADO 4-CANCELADO");
        int opcion = ConsolaUtil.leerEntero(scanner, "Seleccione estado: ", 1, 4);
        return switch (opcion) {
            case 2 -> Estado.CONFIRMADO;
            case 3 -> Estado.TERMINADO;
            case 4 -> Estado.CANCELADO;
            default -> Estado.PENDIENTE;
        };
    }

    private Estado leerEstadoOpcional() {
        String cambiar = ConsolaUtil.leerTexto(scanner, "¿Cambiar estado? S/N: ", true);
        if (!cambiar.equalsIgnoreCase("S")) {
            return null;
        }
        return leerEstado();
    }

    private FormaPago leerFormaPago() {
        System.out.println("Formas de pago: 1-TARJETA 2-TRANSFERENCIA 3-EFECTIVO");
        int opcion = ConsolaUtil.leerEntero(scanner, "Seleccione forma de pago: ", 1, 3);
        return switch (opcion) {
            case 2 -> FormaPago.TRANSFERENCIA;
            case 3 -> FormaPago.EFECTIVO;
            default -> FormaPago.TARJETA;
        };
    }

    private FormaPago leerFormaPagoOpcional() {
        String cambiar = ConsolaUtil.leerTexto(scanner, "¿Cambiar forma de pago? S/N: ", true);
        if (!cambiar.equalsIgnoreCase("S")) {
            return null;
        }
        return leerFormaPago();
    }
}
