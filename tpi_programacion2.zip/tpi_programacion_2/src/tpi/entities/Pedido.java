package tpi.entities;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import tpi.enums.Estado;
import tpi.enums.FormaPago;
import tpi.exception.StockInvalidoException;
import tpi.exception.ValidacionException;
import tpi.interfaces.Calculable;

public class Pedido extends Base implements Calculable {

    private LocalDate fecha;
    private Estado estado;
    private Double total;
    private FormaPago formaPago;
    private List<DetallePedido> detalles;
    private Usuario usuario;

    public Pedido(Long id, LocalDate fecha, Estado estado, FormaPago formaPago, Usuario usuario)
            throws ValidacionException {
        super(id);
        if (usuario == null) {
            throw new ValidacionException("No se puede crear un pedido sin usuario.");
        }
        if (usuario.isEliminado()) {
            throw new ValidacionException("El usuario asociado no está disponible.");
        }
        this.fecha = fecha;
        this.estado = estado;
        this.formaPago = formaPago;
        this.usuario = usuario;
        this.total = 0.0;
        this.detalles = new ArrayList<>();
    }

    public void addDetallePedido(int cantidad, Double precioUnitario, Producto producto)
            throws ValidacionException, StockInvalidoException {
        if (cantidad <= 0) {
            throw new ValidacionException("La cantidad debe ser mayor a 0.");
        }
        if (producto == null || producto.isEliminado()) {
            throw new ValidacionException("El producto no existe o está eliminado.");
        }
        if (!producto.isDisponible()) {
            throw new ValidacionException("El producto no está disponible.");
        }
        int cantidadEnPedido = cantidadYaPedida(producto);
        if (cantidad + cantidadEnPedido > producto.getStock()) {
            throw new StockInvalidoException(
                    "Stock insuficiente para " + producto.getNombre()
                            + ". Disponible: " + (producto.getStock() - cantidadEnPedido));
        }

        Long idDetalle = (long) (detalles.size() + 1);
        DetallePedido nuevoDetalle = new DetallePedido(idDetalle, cantidad, producto);
        detalles.add(nuevoDetalle);
        calcularTotal();
    }

    private int cantidadYaPedida(Producto producto) {
        int acumulado = 0;
        for (DetallePedido detalle : detalles) {
            if (detalle.getProducto() != null
                    && detalle.getProducto().getId().equals(producto.getId())) {
                acumulado += detalle.getCantidad();
            }
        }
        return acumulado;
    }

    public DetallePedido findDetallePedidoByProducto(Producto producto) {
        if (producto == null) {
            return null;
        }
        for (DetallePedido detalle : detalles) {
            if (detalle.getProducto() != null
                    && detalle.getProducto().getId().equals(producto.getId())) {
                return detalle;
            }
        }
        return null;
    }

    public void deleteDetallePedidoByProducto(Producto producto) {
        DetallePedido detalle = findDetallePedidoByProducto(producto);
        if (detalle != null) {
            detalles.remove(detalle);
            calcularTotal();
        }
    }

    public void descontarStockProductos() throws StockInvalidoException {
        for (DetallePedido detalle : detalles) {
            Producto producto = detalle.getProducto();
            int nuevoStock = producto.getStock() - detalle.getCantidad();
            if (nuevoStock < 0) {
                throw new StockInvalidoException("Stock insuficiente al confirmar el pedido.");
            }
            producto.setStock(nuevoStock);
        }
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public Double getTotal() {
        return total;
    }

    public FormaPago getFormaPago() {
        return formaPago;
    }

    public void setFormaPago(FormaPago formaPago) {
        this.formaPago = formaPago;
    }

    public List<DetallePedido> getDetalles() {
        return detalles;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) throws ValidacionException {
        if (usuario == null || usuario.isEliminado()) {
            throw new ValidacionException("Usuario inválido para el pedido.");
        }
        this.usuario = usuario;
    }

    @Override
    public void calcularTotal() {
        this.total = 0.0;
        for (DetallePedido detalle : detalles) {
            this.total += detalle.getSubtotal();
        }
    }

    @Override
    public String toString() {
        String usuarioTxt = usuario != null
                ? usuario.getNombre() + " " + usuario.getApellido() + " (#" + usuario.getId() + ")"
                : "Sin usuario";
        return String.format("[%d] %s | %s | %s | $%.2f | %s",
                getId(), fecha, usuarioTxt, estado, total, formaPago);
    }
}
