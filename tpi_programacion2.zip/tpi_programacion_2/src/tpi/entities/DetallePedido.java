package tpi.entities;

import tpi.exception.ValidacionException;

public class DetallePedido extends Base {

    private int cantidad;
    private Double subtotal;
    private Producto producto;

    public DetallePedido(Long id, int cantidad, Producto producto) throws ValidacionException {
        super(id);
        if (cantidad <= 0) {
            throw new ValidacionException("La cantidad del detalle debe ser mayor a 0.");
        }
        this.cantidad = cantidad;
        this.producto = producto;
        this.subtotal = calcularSubtotal();
    }

    public Double calcularSubtotal() {
        if (producto != null && producto.getPrecio() != null) {
            this.subtotal = cantidad * producto.getPrecio();
        } else {
            this.subtotal = 0.0;
        }
        return subtotal;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) throws ValidacionException {
        if (cantidad <= 0) {
            throw new ValidacionException("La cantidad del detalle debe ser mayor a 0.");
        }
        this.cantidad = cantidad;
        calcularSubtotal();
    }

    public Double getSubtotal() {
        return subtotal;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
        calcularSubtotal();
    }

    @Override
    public String toString() {
        String nombreProducto = producto != null ? producto.getNombre() : "Sin producto";
        return String.format("  - Detalle #%d: %s x %d => $%.2f",
                getId(), nombreProducto, cantidad, subtotal);
    }
}
