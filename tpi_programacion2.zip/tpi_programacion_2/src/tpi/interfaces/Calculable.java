package tpi.interfaces;

public interface Calculable {
    void calcularTotal();
}
