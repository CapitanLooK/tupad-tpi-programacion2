package tpi;

import tpi.repository.CategoriaRepository;
import tpi.repository.PedidoRepository;
import tpi.repository.ProductoRepository;
import tpi.repository.UsuarioRepository;
import tpi.service.CategoriaService;
import tpi.service.PedidoService;
import tpi.service.ProductoService;
import tpi.service.UsuarioService;

public class AppContext {

    private final CategoriaRepository categoriaRepository = new CategoriaRepository();
    private final ProductoRepository productoRepository = new ProductoRepository();
    private final UsuarioRepository usuarioRepository = new UsuarioRepository();
    private final PedidoRepository pedidoRepository = new PedidoRepository();

    private final CategoriaService categoriaService;
    private final ProductoService productoService;
    private final UsuarioService usuarioService;
    private final PedidoService pedidoService;

    public AppContext() {
        this.categoriaService = new CategoriaService(categoriaRepository);
        this.productoService = new ProductoService(productoRepository, categoriaRepository);
        this.usuarioService = new UsuarioService(usuarioRepository);
        this.pedidoService = new PedidoService(pedidoRepository, usuarioRepository, productoRepository);
    }

    public CategoriaService getCategoriaService() {
        return categoriaService;
    }

    public ProductoService getProductoService() {
        return productoService;
    }

    public UsuarioService getUsuarioService() {
        return usuarioService;
    }

    public PedidoService getPedidoService() {
        return pedidoService;
    }
}
