package tpi.exception;

public class EntidadNoEncontradaException extends Exception {
    public EntidadNoEncontradaException(String mensaje) {
        super(mensaje);
    }
}
