package tpi.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import tpi.entities.Producto;

public class ProductoRepository {

    private final Map<Long, Producto> almacen = new HashMap<>();
    private long secuencia = 0;

    public Long nextId() {
        secuencia++;
        return secuencia;
    }

    public void guardar(Producto producto) {
        almacen.put(producto.getId(), producto);
    }

    public Producto buscarPorId(Long id) {
        return almacen.get(id);
    }

    public List<Producto> listarActivos() {
        List<Producto> activos = new ArrayList<>();
        for (Producto producto : almacen.values()) {
            if (!producto.isEliminado()) {
                activos.add(producto);
            }
        }
        return activos;
    }

    public List<Producto> listarActivosPorCategoria(Long categoriaId) {
        List<Producto> filtrados = new ArrayList<>();
        for (Producto producto : almacen.values()) {
            if (!producto.isEliminado()
                    && producto.getCategoria() != null
                    && producto.getCategoria().getId().equals(categoriaId)) {
                filtrados.add(producto);
            }
        }
        return filtrados;
    }
}
