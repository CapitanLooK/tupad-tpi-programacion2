package tpi.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import tpi.entities.Pedido;

public class PedidoRepository {

    private final Map<Long, Pedido> almacen = new HashMap<>();
    private long secuencia = 0;

    public Long nextId() {
        secuencia++;
        return secuencia;
    }

    public void guardar(Pedido pedido) {
        almacen.put(pedido.getId(), pedido);
    }

    public Pedido buscarPorId(Long id) {
        return almacen.get(id);
    }

    public List<Pedido> listarActivos() {
        List<Pedido> activos = new ArrayList<>();
        for (Pedido pedido : almacen.values()) {
            if (!pedido.isEliminado()) {
                activos.add(pedido);
            }
        }
        return activos;
    }

    public List<Pedido> listarActivosPorUsuario(Long usuarioId) {
        List<Pedido> filtrados = new ArrayList<>();
        for (Pedido pedido : almacen.values()) {
            if (!pedido.isEliminado()
                    && pedido.getUsuario() != null
                    && pedido.getUsuario().getId().equals(usuarioId)) {
                filtrados.add(pedido);
            }
        }
        return filtrados;
    }
}
