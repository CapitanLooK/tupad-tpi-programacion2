package tpi.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import tpi.entities.Usuario;

public class UsuarioRepository {

    private final Map<Long, Usuario> almacen = new HashMap<>();
    private long secuencia = 0;

    public Long nextId() {
        secuencia++;
        return secuencia;
    }

    public void guardar(Usuario usuario) {
        almacen.put(usuario.getId(), usuario);
    }

    public Usuario buscarPorId(Long id) {
        return almacen.get(id);
    }

    public List<Usuario> listarActivos() {
        List<Usuario> activos = new ArrayList<>();
        for (Usuario usuario : almacen.values()) {
            if (!usuario.isEliminado()) {
                activos.add(usuario);
            }
        }
        return activos;
    }

    public boolean existeMailActivo(String mail, Long idExcluir) {
        for (Usuario usuario : almacen.values()) {
            if (!usuario.isEliminado()
                    && usuario.getMail().equalsIgnoreCase(mail)
                    && (idExcluir == null || !usuario.getId().equals(idExcluir))) {
                return true;
            }
        }
        return false;
    }
}
