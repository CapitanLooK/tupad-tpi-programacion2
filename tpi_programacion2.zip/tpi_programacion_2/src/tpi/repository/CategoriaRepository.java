package tpi.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import tpi.entities.Categoria;

public class CategoriaRepository {

    private final Map<Long, Categoria> almacen = new HashMap<>();
    private long secuencia = 0;

    public Long nextId() {
        secuencia++;
        return secuencia;
    }

    public void guardar(Categoria categoria) {
        almacen.put(categoria.getId(), categoria);
    }

    public Categoria buscarPorId(Long id) {
        return almacen.get(id);
    }

    public List<Categoria> listarActivas() {
        List<Categoria> activas = new ArrayList<>();
        for (Categoria categoria : almacen.values()) {
            if (!categoria.isEliminado()) {
                activas.add(categoria);
            }
        }
        return activas;
    }

    public boolean existeNombreActivo(String nombre, Long idExcluir) {
        for (Categoria categoria : almacen.values()) {
            if (!categoria.isEliminado()
                    && categoria.getNombre().equalsIgnoreCase(nombre)
                    && (idExcluir == null || !categoria.getId().equals(idExcluir))) {
                return true;
            }
        }
        return false;
    }
}
