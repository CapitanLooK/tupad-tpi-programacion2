package tpi;

import java.util.Scanner;
import tpi.ui.MenuPrincipal;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AppContext context = new AppContext();
        MenuPrincipal menu = new MenuPrincipal(scanner, context);
        menu.iniciar();
        scanner.close();
    }
}
