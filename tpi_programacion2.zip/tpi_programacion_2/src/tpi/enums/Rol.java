package tpi.enums;

public enum Rol {
    ADMIN,
    USUARIO
}
