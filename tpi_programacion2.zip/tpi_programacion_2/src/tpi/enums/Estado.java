package tpi.enums;

public enum Estado {
    PENDIENTE,
    CONFIRMADO,
    TERMINADO,
    CANCELADO
}
