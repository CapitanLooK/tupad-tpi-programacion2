package tpi.enums;

public enum FormaPago {
    TARJETA,
    TRANSFERENCIA,
    EFECTIVO
}
