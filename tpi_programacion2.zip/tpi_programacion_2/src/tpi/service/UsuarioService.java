package tpi.service;

import java.util.List;
import java.util.regex.Pattern;
import tpi.entities.Usuario;
import tpi.enums.Rol;
import tpi.exception.EntidadNoEncontradaException;
import tpi.exception.ValidacionException;
import tpi.repository.UsuarioRepository;

public class UsuarioService {

    private static final Pattern MAIL_BASICO = Pattern.compile("^[\\w.+-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");

    private final UsuarioRepository usuarioRepository;

    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public List<Usuario> listarActivos() {
        return usuarioRepository.listarActivos();
    }

    public Usuario crear(String nombre, String apellido, String mail, String celular, String contrasenia, Rol rol)
            throws ValidacionException {
        validarDatosBasicos(nombre, apellido, mail, celular, contrasenia, rol);
        if (usuarioRepository.existeMailActivo(mail, null)) {
            throw new ValidacionException("Ya existe un usuario con ese mail.");
        }

        Long id = usuarioRepository.nextId();
        Usuario usuario = new Usuario(id, nombre.trim(), apellido.trim(), mail.trim(), celular.trim(),
                contrasenia, rol);
        usuarioRepository.guardar(usuario);
        return usuario;
    }

    public Usuario editar(Long id, String nombre, String apellido, String mail, String celular, String contrasenia,
            Rol rol) throws ValidacionException, EntidadNoEncontradaException {
        Usuario usuario = obtenerActivo(id);

        if (nombre != null && !nombre.isBlank()) {
            usuario.setNombre(nombre.trim());
        }
        if (apellido != null && !apellido.isBlank()) {
            usuario.setApellido(apellido.trim());
        }
        if (mail != null && !mail.isBlank()) {
            validarMail(mail);
            if (usuarioRepository.existeMailActivo(mail.trim(), id)) {
                throw new ValidacionException("Ya existe otro usuario con ese mail.");
            }
            usuario.setMail(mail.trim());
        }
        if (celular != null && !celular.isBlank()) {
            usuario.setCelular(celular.trim());
        }
        if (contrasenia != null && !contrasenia.isBlank()) {
            usuario.setContrasenia(contrasenia);
        }
        if (rol != null) {
            usuario.setRol(rol);
        }
        return usuario;
    }

    public void eliminar(Long id) throws EntidadNoEncontradaException {
        Usuario usuario = obtenerActivo(id);
        usuario.setEliminado(true);
    }

    public Usuario obtenerActivo(Long id) throws EntidadNoEncontradaException {
        Usuario usuario = usuarioRepository.buscarPorId(id);
        if (usuario == null || usuario.isEliminado()) {
            throw new EntidadNoEncontradaException("Usuario no encontrado o eliminado.");
        }
        return usuario;
    }

    private void validarDatosBasicos(String nombre, String apellido, String mail, String celular,
            String contrasenia, Rol rol) throws ValidacionException {
        if (nombre == null || nombre.isBlank()) {
            throw new ValidacionException("El nombre no puede estar vacío.");
        }
        if (apellido == null || apellido.isBlank()) {
            throw new ValidacionException("El apellido no puede estar vacío.");
        }
        validarMail(mail);
        if (celular == null || celular.isBlank()) {
            throw new ValidacionException("El celular no puede estar vacío.");
        }
        if (contrasenia == null || contrasenia.isBlank()) {
            throw new ValidacionException("La contraseña no puede estar vacía.");
        }
        if (rol == null) {
            throw new ValidacionException("Debe seleccionar un rol válido.");
        }
    }

    private void validarMail(String mail) throws ValidacionException {
        if (mail == null || mail.isBlank()) {
            throw new ValidacionException("El mail no puede estar vacío.");
        }
        if (!MAIL_BASICO.matcher(mail.trim()).matches()) {
            throw new ValidacionException("El formato del mail no es válido.");
        }
    }
}
