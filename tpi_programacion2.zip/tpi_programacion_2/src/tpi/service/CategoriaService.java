package tpi.service;

import java.util.List;
import tpi.entities.Categoria;
import tpi.exception.EntidadNoEncontradaException;
import tpi.exception.ValidacionException;
import tpi.repository.CategoriaRepository;

public class CategoriaService {

    private final CategoriaRepository categoriaRepository;

    public CategoriaService(CategoriaRepository categoriaRepository) {
        this.categoriaRepository = categoriaRepository;
    }

    public List<Categoria> listarActivas() {
        return categoriaRepository.listarActivas();
    }

    public Categoria crear(String nombre, String descripcion) throws ValidacionException {
        validarTexto(nombre, "El nombre no puede estar vacío.");
        validarTexto(descripcion, "La descripción no puede estar vacía.");
        if (categoriaRepository.existeNombreActivo(nombre, null)) {
            throw new ValidacionException("Ya existe una categoría con ese nombre.");
        }

        Long id = categoriaRepository.nextId();
        Categoria categoria = new Categoria(id, nombre.trim(), descripcion.trim());
        categoriaRepository.guardar(categoria);
        return categoria;
    }

    public Categoria editar(Long id, String nombre, String descripcion) throws ValidacionException,
            EntidadNoEncontradaException {
        Categoria categoria = obtenerActiva(id);
        if (nombre != null && !nombre.isBlank()) {
            if (categoriaRepository.existeNombreActivo(nombre.trim(), id)) {
                throw new ValidacionException("Ya existe otra categoría con ese nombre.");
            }
            categoria.setNombre(nombre.trim());
        }
        if (descripcion != null && !descripcion.isBlank()) {
            categoria.setDescripcion(descripcion.trim());
        }
        return categoria;
    }

    public void eliminar(Long id) throws EntidadNoEncontradaException, ValidacionException {
        Categoria categoria = obtenerActiva(id);
        if (categoria.tieneProductosActivos()) {
            throw new ValidacionException(
                    "No se puede eliminar la categoría porque tiene productos activos asociados.");
        }
        categoria.setEliminado(true);
    }

    public Categoria obtenerActiva(Long id) throws EntidadNoEncontradaException {
        Categoria categoria = categoriaRepository.buscarPorId(id);
        if (categoria == null || categoria.isEliminado()) {
            throw new EntidadNoEncontradaException("Categoría no encontrada o eliminada.");
        }
        return categoria;
    }

    private void validarTexto(String valor, String mensaje) throws ValidacionException {
        if (valor == null || valor.isBlank()) {
            throw new ValidacionException(mensaje);
        }
    }
}
