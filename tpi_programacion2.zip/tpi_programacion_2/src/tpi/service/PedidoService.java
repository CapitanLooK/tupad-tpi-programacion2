package tpi.service;

import java.time.LocalDate;
import java.util.List;
import tpi.entities.Pedido;
import tpi.entities.Producto;
import tpi.entities.Usuario;
import tpi.enums.Estado;
import tpi.enums.FormaPago;
import tpi.exception.EntidadNoEncontradaException;
import tpi.exception.StockInvalidoException;
import tpi.exception.ValidacionException;
import tpi.repository.PedidoRepository;
import tpi.repository.ProductoRepository;
import tpi.repository.UsuarioRepository;

public class PedidoService {

    private final PedidoRepository pedidoRepository;
    private final UsuarioRepository usuarioRepository;
    private final ProductoRepository productoRepository;

    public PedidoService(PedidoRepository pedidoRepository, UsuarioRepository usuarioRepository,
            ProductoRepository productoRepository) {
        this.pedidoRepository = pedidoRepository;
        this.usuarioRepository = usuarioRepository;
        this.productoRepository = productoRepository;
    }

    public List<Pedido> listarActivos() {
        return pedidoRepository.listarActivos();
    }

    public List<Pedido> listarActivosPorUsuario(Long usuarioId) throws EntidadNoEncontradaException {
        validarUsuarioActivo(usuarioId);
        return pedidoRepository.listarActivosPorUsuario(usuarioId);
    }

    public Pedido crearPedidoConDetalles(Long usuarioId, Estado estado, FormaPago formaPago,
            List<DetalleSolicitud> detallesSolicitud)
            throws ValidacionException, EntidadNoEncontradaException, StockInvalidoException {
        Usuario usuario = validarUsuarioActivo(usuarioId);
        if (detallesSolicitud == null || detallesSolicitud.isEmpty()) {
            throw new ValidacionException("El pedido debe tener al menos un detalle.");
        }

        Long id = pedidoRepository.nextId();
        Pedido pedido = new Pedido(id, LocalDate.now(), estado, formaPago, usuario);

        for (DetalleSolicitud solicitud : detallesSolicitud) {
            Producto producto = productoRepository.buscarPorId(solicitud.productoId());
            if (producto == null || producto.isEliminado()) {
                throw new EntidadNoEncontradaException("Producto no encontrado o eliminado.");
            }
            pedido.addDetallePedido(solicitud.cantidad(), producto.getPrecio(), producto);
        }
        pedido.calcularTotal();
        pedido.descontarStockProductos();
        pedidoRepository.guardar(pedido);
        usuario.agregarPedido(pedido);
        return pedido;
    }

    public Pedido actualizarEstadoYPago(Long id, Estado estado, FormaPago formaPago)
            throws EntidadNoEncontradaException {
        Pedido pedido = obtenerActivo(id);
        if (estado != null) {
            pedido.setEstado(estado);
        }
        if (formaPago != null) {
            pedido.setFormaPago(formaPago);
        }
        return pedido;
    }

    public void eliminar(Long id) throws EntidadNoEncontradaException {
        Pedido pedido = obtenerActivo(id);
        pedido.setEliminado(true);
        for (var detalle : pedido.getDetalles()) {
            detalle.setEliminado(true);
        }
    }

    public Pedido obtenerActivo(Long id) throws EntidadNoEncontradaException {
        Pedido pedido = pedidoRepository.buscarPorId(id);
        if (pedido == null || pedido.isEliminado()) {
            throw new EntidadNoEncontradaException("Pedido no encontrado o eliminado.");
        }
        return pedido;
    }

    private Usuario validarUsuarioActivo(Long usuarioId) throws EntidadNoEncontradaException {
        Usuario usuario = usuarioRepository.buscarPorId(usuarioId);
        if (usuario == null || usuario.isEliminado()) {
            throw new EntidadNoEncontradaException("Usuario no encontrado o eliminado.");
        }
        return usuario;
    }

    public record DetalleSolicitud(Long productoId, int cantidad) {
    }
}
