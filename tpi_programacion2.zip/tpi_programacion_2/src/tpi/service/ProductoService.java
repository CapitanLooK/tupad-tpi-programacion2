package tpi.service;

import java.util.List;
import tpi.entities.Categoria;
import tpi.entities.Producto;
import tpi.exception.EntidadNoEncontradaException;
import tpi.exception.ValidacionException;
import tpi.repository.CategoriaRepository;
import tpi.repository.ProductoRepository;

public class ProductoService {

    private final ProductoRepository productoRepository;
    private final CategoriaRepository categoriaRepository;

    public ProductoService(ProductoRepository productoRepository, CategoriaRepository categoriaRepository) {
        this.productoRepository = productoRepository;
        this.categoriaRepository = categoriaRepository;
    }

    public List<Producto> listarActivos() {
        return productoRepository.listarActivos();
    }

    public List<Producto> listarActivosPorCategoria(Long categoriaId) throws EntidadNoEncontradaException {
        validarCategoriaActiva(categoriaId);
        return productoRepository.listarActivosPorCategoria(categoriaId);
    }

    public Producto crear(String nombre, String descripcion, Double precio, int stock, String imagen,
            boolean disponible, Long categoriaId) throws ValidacionException, EntidadNoEncontradaException {
        validarNombre(nombre);
        validarPrecioYStock(precio, stock);
        Categoria categoria = validarCategoriaActiva(categoriaId);

        Long id = productoRepository.nextId();
        Producto producto = new Producto(id, nombre.trim(), precio, descripcion, stock, imagen, disponible,
                categoria);
        productoRepository.guardar(producto);
        categoria.agregarProducto(producto);
        return producto;
    }

    public Producto editar(Long id, String nombre, String descripcion, Double precio, Integer stock,
            String imagen, Boolean disponible, Long categoriaId)
            throws ValidacionException, EntidadNoEncontradaException {
        Producto producto = obtenerActivo(id);

        if (nombre != null && !nombre.isBlank()) {
            producto.setNombre(nombre.trim());
        }
        if (descripcion != null) {
            producto.setDescripcion(descripcion);
        }
        if (precio != null) {
            validarPrecioYStock(precio, producto.getStock());
            producto.setPrecio(precio);
        }
        if (stock != null) {
            validarPrecioYStock(producto.getPrecio(), stock);
            producto.setStock(stock);
        }
        if (imagen != null) {
            producto.setImagen(imagen);
        }
        if (disponible != null) {
            producto.setDisponible(disponible);
        }
        if (categoriaId != null) {
            Categoria categoria = validarCategoriaActiva(categoriaId);
            if (producto.getCategoria() != null) {
                producto.getCategoria().getProductos().remove(producto);
            }
            producto.setCategoria(categoria);
            categoria.agregarProducto(producto);
        }
        return producto;
    }

    public void eliminar(Long id) throws EntidadNoEncontradaException {
        Producto producto = obtenerActivo(id);
        producto.setEliminado(true);
    }

    public Producto obtenerActivo(Long id) throws EntidadNoEncontradaException {
        Producto producto = productoRepository.buscarPorId(id);
        if (producto == null || producto.isEliminado()) {
            throw new EntidadNoEncontradaException("Producto no encontrado o eliminado.");
        }
        return producto;
    }

    private Categoria validarCategoriaActiva(Long categoriaId) throws EntidadNoEncontradaException {
        Categoria categoria = categoriaRepository.buscarPorId(categoriaId);
        if (categoria == null || categoria.isEliminado()) {
            throw new EntidadNoEncontradaException("La categoría no existe o está eliminada.");
        }
        return categoria;
    }

    private void validarNombre(String nombre) throws ValidacionException {
        if (nombre == null || nombre.isBlank()) {
            throw new ValidacionException("El nombre del producto no puede estar vacío.");
        }
    }

    private void validarPrecioYStock(Double precio, int stock) throws ValidacionException {
        if (precio == null || precio < 0) {
            throw new ValidacionException("El precio debe ser mayor o igual a 0.");
        }
        if (stock < 0) {
            throw new ValidacionException("El stock debe ser mayor o igual a 0.");
        }
    }
}
